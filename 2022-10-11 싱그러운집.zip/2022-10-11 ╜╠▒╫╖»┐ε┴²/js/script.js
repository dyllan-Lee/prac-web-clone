// alert("hellow");
// prompt('이름을 작성해주세요', 'ㅇ');
// console.log('콘솔은 알림이 아닌 개발자를 위함');
// document.write('화면에 출력하기');
// console.log('3 - 2 =' + (3 - 2));
// confirm('바꾸시겠습니까?')
// let myTime = 'we start class at 9:00am';
// alert(myTime);
// alert("변수:" + myTime);

// let yourAge = prompt('how old r u?', '22');
// document.write('your age is :' + yourAge);


/* const presentYear = 2022;
let bornYear = prompt('when did u born?', '1988');
let yourAge = presentYear - bornYear + 1;
document.write('your age is ' + yourAge);
let yourAge = prompt('when did u born?');
var age = 2022 - yourAge;
document.write('your age is :' + age); */

let today = prompt('today?', '20221012');
document.write('today is ' + today);

console.log(today);

let name = prompt('what ur name?', 'dyllan');
alert('Hellow  ' + name)